"""ORM-модели приложения «Учебный архив»."""

from datetime import datetime

from flask_login import UserMixin
from werkzeug.security import check_password_hash, generate_password_hash

from app import db


class TimestampMixin:
    """Общие поля даты создания и обновления."""

    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
        nullable=False,
    )


class User(UserMixin, TimestampMixin, db.Model):
    """Пользователь системы."""

    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    full_name = db.Column(db.String(128), nullable=False)
    role = db.Column(db.String(32), default="student", nullable=False)
    is_active_user = db.Column(db.Boolean, default=True, nullable=False)

    materials = db.relationship("Material", back_populates="author", lazy="dynamic")
    comments = db.relationship("Comment", back_populates="user", lazy="dynamic")
    api_tokens = db.relationship("ApiToken", back_populates="user", lazy="dynamic")

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f"<User {self.username}>"


class Category(TimestampMixin, db.Model):
    """Категория учебных материалов."""

    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=False)
    slug = db.Column(db.String(64), unique=True, nullable=False, index=True)
    description = db.Column(db.Text, default="")

    materials = db.relationship("Material", back_populates="category", lazy="dynamic")

    def __repr__(self):
        return f"<Category {self.name}>"


class Material(TimestampMixin, db.Model):
    """Учебный материал: заметка или файл."""

    __tablename__ = "materials"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False, index=True)
    description = db.Column(db.Text, default="")
    content = db.Column(db.Text, default="")
    material_type = db.Column(db.String(32), default="note", nullable=False)
    file_name = db.Column(db.String(255))
    file_path = db.Column(db.String(512))
    file_size = db.Column(db.Integer, default=0)
    is_public = db.Column(db.Boolean, default=True, nullable=False)
    download_count = db.Column(db.Integer, default=0, nullable=False)

    author_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)

    author = db.relationship("User", back_populates="materials")
    category = db.relationship("Category", back_populates="materials")
    comments = db.relationship("Comment", back_populates="material", lazy="dynamic")

    @property
    def has_file(self) -> bool:
        return bool(self.file_path)

    def __repr__(self):
        return f"<Material {self.title}>"


class Comment(TimestampMixin, db.Model):
    """Комментарий к материалу."""

    __tablename__ = "comments"

    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    material_id = db.Column(db.Integer, db.ForeignKey("materials.id"), nullable=False)

    user = db.relationship("User", back_populates="comments")
    material = db.relationship("Material", back_populates="comments")


class ApiToken(TimestampMixin, db.Model):
    """Персональный токен для REST API."""

    __tablename__ = "api_tokens"

    id = db.Column(db.Integer, primary_key=True)
    token = db.Column(db.String(64), unique=True, nullable=False, index=True)
    label = db.Column(db.String(64), default="default")
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    user = db.relationship("User", back_populates="api_tokens")


class ActivityLog(db.Model):
    """Журнал действий пользователей (экспорт в CSV)."""

    __tablename__ = "activity_logs"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    action = db.Column(db.String(64), nullable=False)
    details = db.Column(db.String(512), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
