"""Скачивание загруженных файлов."""

from pathlib import Path

from flask import Blueprint, abort, send_file
from flask_login import current_user

from app.models import Material
from app.services.material_service import MaterialService
from config import BASE_DIR

files_bp = Blueprint("files", __name__)


@files_bp.route("/download/<int:material_id>")
def download(material_id):
    material = Material.query.get_or_404(material_id)

    if not material.has_file:
        abort(404)

    if not material.is_public:
        if not current_user.is_authenticated or material.author_id != current_user.id:
            abort(403)

    full_path = BASE_DIR / material.file_path
    if not full_path.exists():
        abort(404)

    MaterialService.increment_download(material)
    return send_file(
        full_path,
        as_attachment=True,
        download_name=material.file_name or full_path.name,
    )
