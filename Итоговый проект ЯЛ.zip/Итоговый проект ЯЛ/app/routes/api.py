"""REST API v1."""

from functools import wraps

from flask import Blueprint, jsonify, request
from flask_login import current_user

from app import db
from app.models import ApiToken, Category, Material, User
from app.services.export_service import ExportService
from app.services.external_api import OpenLibraryClient
from app.services.material_service import MaterialService
from config import DEFAULT_API_TOKEN

api_bp = Blueprint("api", __name__)


def require_api_token(f):
    """Декоратор проверки токена в заголовке X-API-Token."""

    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get("X-API-Token") or request.args.get("token")
        if not token:
            return jsonify({"error": "Требуется API-токен"}), 401

        if token == DEFAULT_API_TOKEN:
            request.api_user = None
            return f(*args, **kwargs)

        record = ApiToken.query.filter_by(token=token, is_active=True).first()
        if not record:
            return jsonify({"error": "Недействительный токен"}), 403

        request.api_user = record.user
        return f(*args, **kwargs)

    return decorated


@api_bp.route("/")
def api_index():
    return jsonify(
        {
            "name": "Учебный архив API",
            "version": "1.0",
            "endpoints": [
                "GET /api/v1/materials",
                "GET /api/v1/materials/<id>",
                "POST /api/v1/materials",
                "GET /api/v1/categories",
                "GET /api/v1/stats",
                "GET /api/v1/books/search?q=",
            ],
        }
    )


@api_bp.route("/materials", methods=["GET"])
@require_api_token
def list_materials():
    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 10, type=int), 50)
    category_id = request.args.get("category_id", type=int)

    query = Material.query.filter_by(is_public=True)
    if category_id:
        query = query.filter_by(category_id=category_id)

    pagination = query.order_by(Material.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    items = [_material_to_dict(m) for m in pagination.items]
    return jsonify(
        {
            "items": items,
            "page": pagination.page,
            "pages": pagination.pages,
            "total": pagination.total,
        }
    )


@api_bp.route("/materials/<int:material_id>", methods=["GET"])
@require_api_token
def get_material(material_id):
    material = Material.query.get_or_404(material_id)
    if not material.is_public:
        return jsonify({"error": "Материал недоступен"}), 403
    return jsonify(_material_to_dict(material, detailed=True))


@api_bp.route("/materials", methods=["POST"])
@require_api_token
def create_material_api():
    data = request.get_json(silent=True) or {}
    required = ("title", "category_id", "author_id")
    if not all(data.get(k) for k in required):
        return jsonify({"error": "Нужны поля: title, category_id, author_id"}), 400

    user = User.query.get(data["author_id"])
    if not user:
        return jsonify({"error": "Пользователь не найден"}), 404

    material = Material(
        title=data["title"][:200],
        description=data.get("description", "")[:2000],
        content=data.get("content", ""),
        category_id=data["category_id"],
        author_id=user.id,
        is_public=data.get("is_public", True),
        material_type="note",
    )
    db.session.add(material)
    db.session.commit()
    ExportService.log_action(user.id, "api_create", material.title)
    return jsonify(_material_to_dict(material, detailed=True)), 201


@api_bp.route("/categories", methods=["GET"])
@require_api_token
def list_categories():
    categories = Category.query.order_by(Category.name).all()
    return jsonify(
        [
            {"id": c.id, "name": c.name, "slug": c.slug, "description": c.description}
            for c in categories
        ]
    )


@api_bp.route("/stats", methods=["GET"])
@require_api_token
def stats():
    return jsonify(
        {
            "users": User.query.count(),
            "materials": Material.query.count(),
            "public_materials": Material.query.filter_by(is_public=True).count(),
            "categories": Category.query.count(),
        }
    )


@api_bp.route("/books/search", methods=["GET"])
@require_api_token
def books_search_api():
    query = request.args.get("q", "").strip()
    if not query:
        return jsonify({"error": "Параметр q обязателен"}), 400
    client = OpenLibraryClient()
    return jsonify({"query": query, "results": client.search_books(query)})


def _material_to_dict(material: Material, detailed: bool = False) -> dict:
    data = {
        "id": material.id,
        "title": material.title,
        "description": material.description,
        "category": material.category.name if material.category else None,
        "author": material.author.username if material.author else None,
        "type": material.material_type,
        "is_public": material.is_public,
        "download_count": material.download_count,
        "created_at": material.created_at.isoformat(),
    }
    if detailed:
        data["content"] = material.content
        data["file_name"] = material.file_name
        data["has_file"] = material.has_file
    return data
