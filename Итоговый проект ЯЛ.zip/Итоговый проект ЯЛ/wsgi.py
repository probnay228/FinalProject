"""WSGI для хостинга (PythonAnywhere, Render, Gunicorn)."""

from app import create_app

application = create_app()
