"""Регистрация и авторизация."""

from flask import Blueprint, flash, redirect, render_template, url_for
from flask_login import current_user, login_required, login_user, logout_user

from app import db
from app.forms import LoginForm, RegistrationForm
from app.models import User
from app.services.export_service import ExportService

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))

    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(
            username=form.username.data.strip(),
            email=form.email.data.strip().lower(),
            full_name=form.full_name.data.strip(),
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        ExportService.log_action(user.id, "register", user.username)
        flash("Регистрация успешна. Войдите в систему.", "success")
        return redirect(url_for("auth.login"))

    return render_template("auth/register.html", form=form)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data.strip()).first()
        if user and user.check_password(form.password.data) and user.is_active_user:
            login_user(user, remember=form.remember.data)
            ExportService.log_action(user.id, "login", "")
            flash(f"Добро пожаловать, {user.full_name}!", "success")
            next_page = url_for("main.dashboard")
            return redirect(next_page)

        flash("Неверный логин или пароль.", "danger")

    return render_template("auth/login.html", form=form)


@auth_bp.route("/logout")
@login_required
def logout():
    ExportService.log_action(current_user.id, "logout", "")
    logout_user()
    flash("Вы вышли из системы.", "info")
    return redirect(url_for("main.index"))
