"""WTForms-формы для веб-интерфейса."""

from flask_wtf import FlaskForm
from flask_wtf.file import FileAllowed, FileField
from wtforms import BooleanField, PasswordField, SelectField, StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Email, EqualTo, Length, Optional, ValidationError

from app.models import Category, User


class RegistrationForm(FlaskForm):
    username = StringField("Логин", validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=120)])
    full_name = StringField("ФИО", validators=[DataRequired(), Length(max=128)])
    password = PasswordField("Пароль", validators=[DataRequired(), Length(min=6, max=72)])
    password2 = PasswordField(
        "Повтор пароля",
        validators=[DataRequired(), EqualTo("password", message="Пароли должны совпадать.")],
    )
    submit = SubmitField("Зарегистрироваться")

    def validate_username(self, field):
        if User.query.filter_by(username=field.data).first():
            raise ValidationError("Такой логин уже занят.")

    def validate_email(self, field):
        if User.query.filter_by(email=field.data).first():
            raise ValidationError("Email уже используется.")


class LoginForm(FlaskForm):
    username = StringField("Логин", validators=[DataRequired()])
    password = PasswordField("Пароль", validators=[DataRequired()])
    remember = BooleanField("Запомнить меня")
    submit = SubmitField("Войти")


class MaterialForm(FlaskForm):
    title = StringField("Название", validators=[DataRequired(), Length(max=200)])
    description = TextAreaField("Описание", validators=[Optional(), Length(max=2000)])
    content = TextAreaField("Текст заметки", validators=[Optional()])
    category_id = SelectField("Категория", coerce=int, validators=[DataRequired()])
    is_public = BooleanField("Публичный доступ", default=True)
    file = FileField(
        "Файл",
        validators=[
            Optional(),
            FileAllowed(["pdf", "png", "jpg", "jpeg", "gif", "txt", "doc", "docx", "zip"]),
        ],
    )
    submit = SubmitField("Сохранить")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.category_id.choices = [
            (c.id, c.name) for c in Category.query.order_by(Category.name).all()
        ]


class CommentForm(FlaskForm):
    text = TextAreaField("Комментарий", validators=[DataRequired(), Length(min=2, max=1000)])
    submit = SubmitField("Отправить")


class SearchBookForm(FlaskForm):
    query = StringField("Поиск книги (сторонний API)", validators=[DataRequired(), Length(max=120)])
    submit = SubmitField("Найти в Open Library")
