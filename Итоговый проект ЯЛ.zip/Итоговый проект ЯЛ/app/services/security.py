"""Утилиты безопасности."""

import secrets

from werkzeug.security import generate_password_hash


def hash_password(password: str) -> str:
    return generate_password_hash(password)


def generate_api_token() -> str:
    return secrets.token_urlsafe(32)
