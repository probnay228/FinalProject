import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TAG = re.compile(r"</?m" + "otion" + r">")

for path in ROOT.rglob("*"):
    if path.suffix.lower() not in {".html", ".py", ".md"}:
        continue
    text = path.read_text(encoding="utf-8")
    cleaned = TAG.sub("", text)
    if cleaned != text:
        path.write_text(cleaned, encoding="utf-8")
        print("cleaned", path.relative_to(ROOT))
