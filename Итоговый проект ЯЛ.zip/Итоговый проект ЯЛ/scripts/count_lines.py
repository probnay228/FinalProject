"""Подсчёт строк содержательного Python-кода."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
total = 0
for path in sorted(ROOT.rglob("*.py")):
    if "venv" in path.parts:
        continue
    lines = len(path.read_text(encoding="utf-8").splitlines())
    total += lines
    print(f"{lines:4d}  {path.relative_to(ROOT)}")

print("-" * 40)
print(f"Итого строк Python: {total}")
