# Учебный архив

Веб-приложение и REST API для обмена учебными материалами (контрольная работа WEB, Яндекс.Лицей).

## Возможности

- Регистрация и авторизация пользователей
- Публикация заметок и загрузка файлов
- Категории, комментарии, личный кабинет
- REST API с токеном доступа
- Поиск книг через Open Library API
- Экспорт данных в CSV и TXT
- SQLite, ORM SQLAlchemy, интерфейс Bootstrap 5

## Быстрый старт

```bash
cd "E:\Итоговый проект ЯЛ"
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python run.py
```

Откройте в браузере: http://127.0.0.1:5000

**Демо-аккаунт:** `demo` / `demo1234`

**API-токен:** `yl-archive-api-token-2026` (заголовок `X-API-Token`)

## Примеры API

```bash
curl -H "X-API-Token: yl-archive-api-token-2026" http://127.0.0.1:5000/api/v1/materials
curl -H "X-API-Token: yl-archive-api-token-2026" "http://127.0.0.1:5000/api/v1/books/search?q=python"
```

## Хостинг

Для деплоя используйте `wsgi.py` и Gunicorn:

```bash
gunicorn -w 2 -b 0.0.0.0:8000 wsgi:application
```

Подходят PythonAnywhere, Render, Railway и аналоги.

## Структура

- `app/` — код приложения (модели, маршруты, сервисы)
- `templates/` — HTML (Bootstrap)
- `static/` — CSS и JS
- `docs/` — ТЗ, пояснительная записка, презентация
- `tests/` — автотесты

## Тесты

```bash
pip install pytest
pytest tests/ -v
```
