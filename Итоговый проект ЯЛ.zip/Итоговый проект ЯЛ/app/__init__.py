"""Фабрика приложения Flask."""

import os
from pathlib import Path

from flask import Flask
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy

from config import BASE_DIR

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.login_message = "Войдите, чтобы продолжить."
login_manager.login_message_category = "warning"


def create_app(config_object=None):
    """Создаёт и настраивает экземпляр приложения."""
    app = Flask(__name__, template_folder="../templates", static_folder="../static")

    if config_object is None:
        app.config.from_object("config")
    elif isinstance(config_object, str):
        app.config.from_object(config_object)
    else:
        app.config.from_object(config_object)

    _ensure_directories(app)

    db.init_app(app)
    login_manager.init_app(app)

    from app.models import User  # noqa: F401 — регистрация моделей

    @login_manager.user_loader
    def load_user(user_id):
        from app.models import User

        return User.query.get(int(user_id))

    from app.routes.auth import auth_bp
    from app.routes.main import main_bp
    from app.routes.api import api_bp
    from app.routes.files import files_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(api_bp, url_prefix="/api/v1")
    app.register_blueprint(files_bp, url_prefix="/files")

    with app.app_context():
        db.create_all()
        if not app.config.get("TESTING"):
            _seed_demo_data()

    return app


def _ensure_directories(app):
    """Создаёт каталоги для БД, загрузок и экспорта."""
    paths = [
        BASE_DIR / "data",
        Path(app.config["UPLOAD_FOLDER"]),
        BASE_DIR / "exports",
    ]
    for path in paths:
        os.makedirs(path, exist_ok=True)


def _seed_demo_data():
    """Добавляет демо-пользователя и материалы при первом запуске."""
    from app.models import Category, Material, User

    if User.query.filter_by(username="demo").first():
        return

    admin = User(
        username="demo",
        email="demo@yandex.lyceum.local",
        full_name="Демо Пользователь",
        role="student",
    )
    admin.set_password("demo1234")
    db.session.add(admin)

    categories = [
        Category(name="Математика", slug="math", description="Конспекты и задачи"),
        Category(name="Информатика", slug="informatics", description="Программирование и WEB"),
        Category(name="Физика", slug="physics", description="Лабораторные и формулы"),
    ]
    db.session.add_all(categories)
    db.session.flush()

    materials = [
        Material(
            title="Введение в Flask",
            description="Краткий конспект по созданию веб-приложений на Python.",
            author_id=admin.id,
            category_id=categories[1].id,
            material_type="note",
            is_public=True,
        ),
        Material(
            title="REST API — шпаргалка",
            description="Методы HTTP, коды ответов, примеры JSON.",
            author_id=admin.id,
            category_id=categories[1].id,
            material_type="note",
            is_public=True,
        ),
    ]
    db.session.add_all(materials)
    db.session.commit()
