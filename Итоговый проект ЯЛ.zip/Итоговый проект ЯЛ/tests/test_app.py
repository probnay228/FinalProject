"""Базовые тесты приложения."""

import json

import pytest

from app import create_app, db
from app.models import Category, Material, User
from config import TestConfig


@pytest.fixture
def app():
    application = create_app(TestConfig)
    with application.app_context():
        user = User(username="tester", email="t@test.ru", full_name="Тест Тестов")
        user.set_password("secret12")
        cat = Category(name="Тест", slug="test", description="")
        db.session.add_all([user, cat])
        db.session.commit()
        material = Material(
            title="Тестовый материал",
            description="Описание",
            author_id=user.id,
            category_id=cat.id,
            is_public=True,
        )
        db.session.add(material)
        db.session.commit()
    yield application


@pytest.fixture
def client(app):
    return app.test_client()


def test_index_page(client):
    response = client.get("/")
    assert response.status_code == 200
    assert "Учебный архив".encode() in response.data


def test_api_materials_requires_token(client):
    response = client.get("/api/v1/materials")
    assert response.status_code == 401


def test_api_materials_with_token(client):
    headers = {"X-API-Token": "yl-archive-api-token-2026"}
    response = client.get("/api/v1/materials", headers=headers)
    assert response.status_code == 200
    payload = json.loads(response.data)
    assert "items" in payload
    assert len(payload["items"]) >= 1


def test_api_stats(client):
    headers = {"X-API-Token": "yl-archive-api-token-2026"}
    response = client.get("/api/v1/stats", headers=headers)
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data["materials"] >= 1
