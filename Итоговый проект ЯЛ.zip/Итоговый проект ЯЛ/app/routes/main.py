"""Основные страницы веб-приложения."""

from pathlib import Path

from flask import Blueprint, abort, flash, redirect, render_template, request, send_file, url_for
from flask_login import current_user, login_required

from app import db
from app.forms import CommentForm, MaterialForm, SearchBookForm
from app.models import Category, Comment, Material
from app.services.export_service import ExportService
from app.services.external_api import OpenLibraryClient
from app.services.material_service import MaterialService
from config import BASE_DIR, ITEMS_PER_PAGE

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    latest = (
        Material.query.filter_by(is_public=True)
        .order_by(Material.created_at.desc())
        .limit(6)
        .all()
    )
    categories = Category.query.order_by(Category.name).all()
    from app.models import User

    stats = {
        "materials": Material.query.count(),
        "users": User.query.count(),
        "categories": Category.query.count(),
    }
    return render_template("main/index.html", latest=latest, categories=categories, stats=stats)


@main_bp.route("/dashboard")
@login_required
def dashboard():
    my_materials = (
        current_user.materials.order_by(Material.created_at.desc()).limit(10).all()
    )
    return render_template("main/dashboard.html", materials=my_materials)


@main_bp.route("/materials")
def materials_list():
    page = request.args.get("page", 1, type=int)
    category_slug = request.args.get("category")
    query = Material.query.filter_by(is_public=True)

    if category_slug:
        category = Category.query.filter_by(slug=category_slug).first_or_404()
        query = query.filter_by(category_id=category.id)
    else:
        category = None

    pagination = query.order_by(Material.created_at.desc()).paginate(
        page=page, per_page=ITEMS_PER_PAGE, error_out=False
    )
    categories = Category.query.order_by(Category.name).all()
    return render_template(
        "main/materials.html",
        pagination=pagination,
        categories=categories,
        active_category=category,
    )


@main_bp.route("/materials/<int:material_id>")
def material_detail(material_id):
    material = Material.query.get_or_404(material_id)
    if not material.is_public and (
        not current_user.is_authenticated or material.author_id != current_user.id
    ):
        abort(403)

    form = CommentForm()
    comments = material.comments.order_by(Comment.created_at.desc()).all()
    return render_template(
        "main/material_detail.html",
        material=material,
        form=form,
        comments=comments,
    )


@main_bp.route("/materials/new", methods=["GET", "POST"])
@login_required
def material_create():
    form = MaterialForm()
    if form.validate_on_submit():
        MaterialService.create_from_form(form, form.file.data)
        flash("Материал создан.", "success")
        return redirect(url_for("main.dashboard"))

    return render_template("main/material_form.html", form=form, title="Новый материал")


@main_bp.route("/materials/<int:material_id>/edit", methods=["GET", "POST"])
@login_required
def material_edit(material_id):
    material = Material.query.get_or_404(material_id)
    if material.author_id != current_user.id:
        abort(403)

    form = MaterialForm(obj=material)
    if form.validate_on_submit():
        MaterialService.update_from_form(material, form, form.file.data)
        flash("Материал обновлён.", "success")
        return redirect(url_for("main.material_detail", material_id=material.id))

    return render_template("main/material_form.html", form=form, title="Редактирование", material=material)


@main_bp.route("/materials/<int:material_id>/delete", methods=["POST"])
@login_required
def material_delete(material_id):
    material = Material.query.get_or_404(material_id)
    if material.author_id != current_user.id:
        abort(403)
    MaterialService.delete(material)
    flash("Материал удалён.", "info")
    return redirect(url_for("main.dashboard"))


@main_bp.route("/materials/<int:material_id>/comment", methods=["POST"])
@login_required
def add_comment(material_id):
    material = Material.query.get_or_404(material_id)
    form = CommentForm()
    if form.validate_on_submit():
        comment = Comment(text=form.text.data.strip(), user_id=current_user.id, material_id=material.id)
        db.session.add(comment)
        db.session.commit()
        ExportService.log_action(current_user.id, "comment", str(material_id))
        flash("Комментарий добавлен.", "success")
    else:
        flash("Не удалось добавить комментарий.", "warning")
    return redirect(url_for("main.material_detail", material_id=material_id))


@main_bp.route("/books/search", methods=["GET", "POST"])
def books_search():
    form = SearchBookForm()
    results = []
    if form.validate_on_submit():
        client = OpenLibraryClient()
        results = client.search_books(form.query.data.strip())
        if not results:
            flash("По запросу ничего не найдено или API недоступен.", "warning")
    return render_template("main/books_search.html", form=form, results=results)


@main_bp.route("/export/materials.csv")
@login_required
def export_materials():
    service = ExportService(BASE_DIR / "exports")
    path = service.export_materials_csv()
    ExportService.log_action(current_user.id, "export_csv", path.name)
    return send_file(path, as_attachment=True, download_name=path.name)


@main_bp.route("/export/users.txt")
@login_required
def export_users():
    service = ExportService(BASE_DIR / "exports")
    path = service.export_users_txt()
    ExportService.log_action(current_user.id, "export_txt", path.name)
    return send_file(path, as_attachment=True, download_name=path.name)


@main_bp.route("/about")
def about():
    return render_template("main/about.html")
