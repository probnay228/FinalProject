"""Интеграция со сторонним REST API Open Library."""

import requests
from flask import current_app


class OpenLibraryClient:
    """Клиент для поиска книг по открытому API."""

    TIMEOUT = 8

    def __init__(self, base_url=None):
        self.base_url = base_url or current_app.config["OPEN_LIBRARY_SEARCH_URL"]

    def search_books(self, query: str, limit: int = 8) -> list[dict]:
        params = {"q": query, "limit": limit, "fields": "title,author_name,first_publish_year,isbn"}
        try:
            response = requests.get(self.base_url, params=params, timeout=self.TIMEOUT)
            response.raise_for_status()
            docs = response.json().get("docs", [])
        except (requests.RequestException, ValueError):
            return []

        results = []
        for doc in docs:
            authors = ", ".join(doc.get("author_name", [])[:3]) or "Неизвестный автор"
            isbn_list = doc.get("isbn") or []
            results.append(
                {
                    "title": doc.get("title", "Без названия"),
                    "authors": authors,
                    "year": doc.get("first_publish_year"),
                    "isbn": isbn_list[0] if isbn_list else None,
                }
            )
        return results
