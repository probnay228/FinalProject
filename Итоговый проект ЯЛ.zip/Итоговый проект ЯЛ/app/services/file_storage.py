"""Сохранение и проверка загружаемых файлов."""

import os
import uuid
from pathlib import Path

from flask import current_app
from werkzeug.utils import secure_filename


def allowed_file(filename: str) -> bool:
    if "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in current_app.config["ALLOWED_EXTENSIONS"]


def save_upload(file_storage) -> tuple[str, str, int]:
    """
    Сохраняет файл в каталог uploads.
    Возвращает (оригинальное_имя, относительный_путь, размер).
    """
    if not file_storage or not file_storage.filename:
        return "", "", 0

    filename = secure_filename(file_storage.filename)
    if not allowed_file(filename):
        raise ValueError("Недопустимый тип файла.")

    ext = filename.rsplit(".", 1)[1].lower()
    unique_name = f"{uuid.uuid4().hex}.{ext}"
    upload_dir = Path(current_app.config["UPLOAD_FOLDER"])
    upload_dir.mkdir(parents=True, exist_ok=True)
    full_path = upload_dir / unique_name
    file_storage.save(full_path)
    size = os.path.getsize(full_path)
    relative = str(Path("uploads") / unique_name)
    return filename, relative, size


def delete_file(relative_path: str) -> None:
    if not relative_path:
        return
    base = Path(current_app.root_path).parent
    full = base / relative_path
    if full.exists():
        full.unlink()
