"""Экспорт данных в CSV и TXT."""

import csv
from datetime import datetime
from pathlib import Path

from app import db
from app.models import ActivityLog, Material, User


class ExportService:
    """Формирует отчёты для скачивания."""

    def __init__(self, export_dir: Path):
        self.export_dir = export_dir
        self.export_dir.mkdir(parents=True, exist_ok=True)

    def export_materials_csv(self) -> Path:
        filename = f"materials_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
        path = self.export_dir / filename
        materials = Material.query.order_by(Material.created_at.desc()).all()

        with path.open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f, delimiter=";")
            writer.writerow(
                ["id", "title", "category", "author", "type", "public", "downloads", "created_at"]
            )
            for m in materials:
                writer.writerow(
                    [
                        m.id,
                        m.title,
                        m.category.name if m.category else "",
                        m.author.username if m.author else "",
                        m.material_type,
                        int(m.is_public),
                        m.download_count,
                        m.created_at.isoformat(),
                    ]
                )
        return path

    def export_users_txt(self) -> Path:
        filename = f"users_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.txt"
        path = self.export_dir / filename
        users = User.query.order_by(User.username).all()
        lines = ["Список пользователей «Учебный архив»", "=" * 40]
        for u in users:
            lines.append(f"{u.id}. {u.full_name} (@{u.username}) — {u.email} [{u.role}]")
        path.write_text("\n".join(lines), encoding="utf-8")
        return path

    @staticmethod
    def log_action(user_id: int | None, action: str, details: str = "") -> None:
        entry = ActivityLog(user_id=user_id, action=action, details=details)
        db.session.add(entry)
        db.session.commit()
