"""Конфигурация приложения «Учебный архив»."""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# Секретный ключ — в продакшене задавать через переменную окружения
SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-change-in-production-yl2026")

# База данных SQLite
SQLALCHEMY_DATABASE_URI = os.environ.get(
    "DATABASE_URL",
    f"sqlite:///{BASE_DIR / 'data' / 'app.db'}",
)
SQLALCHEMY_TRACK_MODIFICATIONS = False

# Загрузка файлов
UPLOAD_FOLDER = str(BASE_DIR / "uploads")
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 МБ
ALLOWED_EXTENSIONS = {"pdf", "png", "jpg", "jpeg", "gif", "txt", "doc", "docx", "zip"}

# REST API
API_TOKEN_HEADER = "X-API-Token"
DEFAULT_API_TOKEN = os.environ.get("API_TOKEN", "yl-archive-api-token-2026")

# Сторонний API — Open Library (книги по ISBN/названию)
OPEN_LIBRARY_SEARCH_URL = "https://openlibrary.org/search.json"

# Пагинация
ITEMS_PER_PAGE = 10


class TestConfig:
    """Конфигурация для автотестов."""

    TESTING = True
    SECRET_KEY = "test-secret"
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = str(BASE_DIR / "test_uploads")
    WTF_CSRF_ENABLED = False
    OPEN_LIBRARY_SEARCH_URL = OPEN_LIBRARY_SEARCH_URL
    DEFAULT_API_TOKEN = DEFAULT_API_TOKEN
