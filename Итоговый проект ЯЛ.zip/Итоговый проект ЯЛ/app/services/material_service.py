"""Бизнес-логика работы с материалами."""

from flask_login import current_user

from app import db
from app.models import Material
from app.services.export_service import ExportService
from app.services.file_storage import delete_file, save_upload


class MaterialService:
    """Создание, обновление и удаление материалов."""

    @staticmethod
    def create_from_form(form, file_storage=None) -> Material:
        material = Material(
            title=form.title.data.strip(),
            description=(form.description.data or "").strip(),
            content=(form.content.data or "").strip(),
            category_id=form.category_id.data,
            is_public=form.is_public.data,
            author_id=current_user.id,
            material_type="note",
        )

        if file_storage and file_storage.filename:
            original, rel_path, size = save_upload(file_storage)
            material.file_name = original
            material.file_path = rel_path
            material.file_size = size
            material.material_type = "file"

        db.session.add(material)
        db.session.commit()
        ExportService.log_action(current_user.id, "create_material", material.title)
        return material

    @staticmethod
    def update_from_form(material: Material, form, file_storage=None) -> Material:
        material.title = form.title.data.strip()
        material.description = (form.description.data or "").strip()
        material.content = (form.content.data or "").strip()
        material.category_id = form.category_id.data
        material.is_public = form.is_public.data

        if file_storage and file_storage.filename:
            delete_file(material.file_path)
            original, rel_path, size = save_upload(file_storage)
            material.file_name = original
            material.file_path = rel_path
            material.file_size = size
            material.material_type = "file"

        db.session.commit()
        ExportService.log_action(current_user.id, "update_material", str(material.id))
        return material

    @staticmethod
    def delete(material: Material) -> None:
        delete_file(material.file_path)
        ExportService.log_action(current_user.id, "delete_material", material.title)
        db.session.delete(material)
        db.session.commit()

    @staticmethod
    def increment_download(material: Material) -> None:
        material.download_count += 1
        db.session.commit()
